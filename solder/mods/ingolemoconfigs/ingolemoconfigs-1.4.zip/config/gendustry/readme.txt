Any .cfg files in this directory will be loaded after the internal configuration, in alphabetic order
Files in 'overrides' directory with matching names cab be used to override internal configuration
